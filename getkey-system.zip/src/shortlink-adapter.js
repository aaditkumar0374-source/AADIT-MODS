/**
 * Provider-specific adapter template.
 *
 * Do not mark a checkpoint verified based only on a browser redirect or query parameter.
 * Implement the provider's documented API and validate a signed callback/webhook server-side.
 * Each provider uses different parameter names, signatures, and API response formats.
 */
async function createChallenge(_input) {
  throw new Error("Shortlink adapter is not implemented. Select a provider and follow its official API documentation.");
}

async function verifyCallback(_req) {
  // MUST validate the provider's HMAC/signature, timestamp, replay protection,
  // and map its signed challenge ID to your own challenge ID.
  throw new Error("Shortlink callback verification is not implemented.");
}

module.exports = { createChallenge, verifyCallback };
