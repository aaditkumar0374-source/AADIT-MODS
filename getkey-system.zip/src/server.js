require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("node:crypto");
const path = require("node:path");
const { createClient } = require("@supabase/supabase-js");
const { z } = require("zod");

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "..", "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: true, legacyHeaders: false }));

const required = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "KEY_HASH_SECRET", "ADMIN_USERNAME", "ADMIN_PASSWORD"];
for (const name of required) {
  if (!process.env[name]) console.warn(`[config] Missing ${name}`);
}
const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

const sessions = new Map(); // For production, use a durable session store.
const challenges = new Map(); // Short-lived local challenge state; use Redis for multi-instance deployments.
const hash = (s) => crypto.createHmac("sha256", process.env.KEY_HASH_SECRET || "dev-only-change-me").update(s).digest("hex");
const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString("base64url");
const keyString = () => "HK-" + crypto.randomBytes(18).toString("hex").toUpperCase().match(/.{1,6}/g).join("-");
const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function requireDb(req, res, next) {
  if (!supabase) return res.status(503).json({ error: "Supabase is not configured. Follow README setup steps." });
  next();
}
function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) return res.status(401).json({ error: "Admin login required." });
  next();
}
function safeExpiry(input) {
  const now = Date.now();
  if (input.mode === "preset") {
    const durations = { "1h": 3600_000, "24h": 86_400_000, "7d": 604_800_000, "30d": 2_592_000_000 };
    if (!durations[input.preset]) throw new Error("Unsupported expiry preset.");
    return new Date(now + durations[input.preset]).toISOString();
  }
  const date = new Date(input.expiresAt);
  if (!input.expiresAt || Number.isNaN(date.getTime()) || date.getTime() <= now) throw new Error("Custom expiry must be a future date/time.");
  return date.toISOString();
}

app.get("/api/health", (_req, res) => res.json({ ok: true, shortlinkProvider: process.env.SHORTLINK_PROVIDER || "disabled" }));

app.post("/api/admin/login", requireDb, asyncRoute(async (req, res) => {
  const parsed = z.object({ username: z.string().min(1).max(100), password: z.string().min(1).max(200) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Username and password are required." });
  const { username, password } = parsed.data;
  const expectedUser = process.env.ADMIN_USERNAME || "";
  const expectedPass = process.env.ADMIN_PASSWORD || "";
  const a = Buffer.from(username), b = Buffer.from(expectedUser);
  const c = Buffer.from(password), d = Buffer.from(expectedPass);
  const userOk = a.length === b.length && crypto.timingSafeEqual(a, b);
  const passOk = c.length === d.length && crypto.timingSafeEqual(c, d);
  if (!userOk || !passOk) return res.status(401).json({ error: "Invalid credentials." });
  const token = randomToken(32);
  sessions.set(token, { expiresAt: Date.now() + 8 * 60 * 60 * 1000 });
  res.json({ token, expiresInSeconds: 28800 });
}));

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  sessions.delete(token);
  res.json({ ok: true });
});

app.get("/api/admin/keys", requireDb, requireAdmin, asyncRoute(async (_req, res) => {
  const { data, error } = await supabase.from("access_keys")
    .select("id,key_prefix,expires_at,status,max_devices,created_at,checkpoint_verified_at")
    .order("created_at", { ascending: false }).limit(200);
  if (error) throw error;
  res.json({ keys: data || [] });
}));

app.post("/api/admin/keys", requireDb, requireAdmin, asyncRoute(async (req, res) => {
  const schema = z.object({
    expiryMode: z.enum(["preset", "custom"]),
    preset: z.enum(["1h", "24h", "7d", "30d"]).optional(),
    expiresAt: z.string().optional(),
    maxDevices: z.number().int().min(1).max(100).default(5)
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid key options." });
  let expiresAt;
  try { expiresAt = safeExpiry({ mode: parsed.data.expiryMode, preset: parsed.data.preset, expiresAt: parsed.data.expiresAt }); }
  catch (e) { return res.status(400).json({ error: e.message }); }
  const rawKey = keyString();
  const { data, error } = await supabase.from("access_keys").insert({
    key_hash: hash(rawKey), key_prefix: rawKey.slice(0, 9), expires_at: expiresAt,
    status: "active", max_devices: parsed.data.maxDevices
  }).select("id,key_prefix,expires_at,status,max_devices,created_at").single();
  if (error) throw error;
  // Raw key is returned once; only its hash is persisted.
  res.status(201).json({ key: rawKey, record: data });
}));

app.post("/api/admin/keys/:id/revoke", requireDb, requireAdmin, asyncRoute(async (req, res) => {
  const { error } = await supabase.from("access_keys").update({ status: "revoked" }).eq("id", req.params.id);
  if (error) throw error;
  res.json({ ok: true });
}));

// Begin a shortlink challenge. A provider adapter must create the provider link and store its provider-specific challenge ID.
app.post("/api/checkpoint/start", requireDb, asyncRoute(async (req, res) => {
  const schema = z.object({ returnUrl: z.string().url().optional() });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return res.status(400).json({ error: "Invalid request." });
  const provider = process.env.SHORTLINK_PROVIDER || "disabled";
  if (provider === "disabled") {
    return res.status(501).json({
      error: "Shortlink provider is not configured yet.",
      detail: "Choose a provider and implement its documented create-link and server-side verification API in src/shortlink-adapter.js."
    });
  }
  const adapter = require("./shortlink-adapter");
  const challenge = await adapter.createChallenge({ returnUrl: parsed.data.returnUrl });
  const id = randomToken(24);
  challenges.set(id, { providerChallengeId: challenge.providerChallengeId, verified: false, expiresAt: Date.now() + 15 * 60_000 });
  res.json({ challengeId: id, shortlinkUrl: challenge.shortlinkUrl, expiresInSeconds: 900 });
}));

// Provider callback: adapter must authenticate the provider's signature before this endpoint trusts the event.
app.post("/api/checkpoint/callback", requireDb, asyncRoute(async (req, res) => {
  const adapter = require("./shortlink-adapter");
  const event = await adapter.verifyCallback(req);
  if (!event || !event.challengeId) return res.status(401).json({ error: "Unverified provider callback." });
  const ch = challenges.get(event.challengeId);
  if (!ch || ch.expiresAt < Date.now()) return res.status(400).json({ error: "Challenge missing or expired." });
  ch.verified = true;
  ch.verifiedAt = new Date().toISOString();
  challenges.set(event.challengeId, ch);
  res.json({ ok: true });
}));

app.get("/api/checkpoint/status/:id", (req, res) => {
  const ch = challenges.get(req.params.id);
  if (!ch || ch.expiresAt < Date.now()) return res.status(404).json({ verified: false, error: "Challenge expired or not found." });
  res.json({ verified: !!ch.verified });
});

// Issue a key only after a provider-verified checkpoint. Multi-device allowance is capped per key.
app.post("/api/keys/claim", requireDb, asyncRoute(async (req, res) => {
  const parsed = z.object({ challengeId: z.string().min(10), preset: z.enum(["1h", "24h", "7d", "30d"]).optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request." });
  const challenge = challenges.get(parsed.data.challengeId);
  if (!challenge || !challenge.verified || challenge.expiresAt < Date.now()) {
    return res.status(403).json({ error: "Complete the verified shortlink checkpoint first." });
  }
  // Keys are normally issued by admin. This claim endpoint can be adapted to assign a verified key pool.
  // For this starter, require an admin-created key and return an explicit integration notice instead of minting untracked keys.
  res.status(501).json({ error: "Checkpoint verified. Configure a key-pool/claim policy before enabling public key issuance." });
}));

app.post("/api/keys/validate", requireDb, asyncRoute(async (req, res) => {
  const parsed = z.object({
    key: z.string().min(8).max(200),
    deviceId: z.string().min(8).max(200)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ valid: false, error: "Key and device ID are required." });
  const { data: row, error } = await supabase.from("access_keys")
    .select("id,expires_at,status,max_devices").eq("key_hash", hash(parsed.data.key)).maybeSingle();
  if (error) throw error;
  if (!row || row.status !== "active" || new Date(row.expires_at).getTime() <= Date.now()) {
    return res.status(403).json({ valid: false, error: "Key is invalid, revoked, or expired." });
  }
  const deviceHash = hash("device:" + parsed.data.deviceId);
  const { data: existing, error: existingError } = await supabase.from("key_devices")
    .select("id").eq("key_id", row.id).eq("device_hash", deviceHash).maybeSingle();
  if (existingError) throw existingError;
  if (!existing) {
    const { count, error: countError } = await supabase.from("key_devices")
      .select("id", { count: "exact", head: true }).eq("key_id", row.id);
    if (countError) throw countError;
    if ((count || 0) >= row.max_devices) {
      return res.status(403).json({ valid: false, error: "Device limit reached for this key." });
    }
    const { error: insertError } = await supabase.from("key_devices").insert({ key_id: row.id, device_hash: deviceHash });
    if (insertError) {
      // Concurrent registration can race; recheck whether this exact device was inserted.
      const { data: raced } = await supabase.from("key_devices").select("id").eq("key_id", row.id).eq("device_hash", deviceHash).maybeSingle();
      if (!raced) throw insertError;
    }
  }
  res.json({ valid: true, expiresAt: row.expires_at, maxDevices: row.max_devices });
}));

app.use((err, _req, res, _next) => {
  console.error("[error]", err.message || err);
  res.status(500).json({ error: "Server error. Check server logs." });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Get Key System listening on http://localhost:${port}`));
