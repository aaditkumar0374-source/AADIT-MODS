create extension if not exists pgcrypto;

create table if not exists public.access_keys (
  id uuid primary key default gen_random_uuid(),
  key_hash text not null unique,
  key_prefix text not null,
  expires_at timestamptz not null,
  status text not null default 'active' check (status in ('active', 'revoked')),
  max_devices integer not null default 5 check (max_devices between 1 and 100),
  checkpoint_verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.key_devices (
  id uuid primary key default gen_random_uuid(),
  key_id uuid not null references public.access_keys(id) on delete cascade,
  device_hash text not null,
  created_at timestamptz not null default now(),
  unique (key_id, device_hash)
);

alter table public.access_keys enable row level security;
alter table public.key_devices enable row level security;

-- No anon/authenticated policies are intentionally added. All database access in this starter
-- goes through the Node server using the service-role key. Never expose that key in frontend code.
create index if not exists access_keys_created_at_idx on public.access_keys(created_at desc);
create index if not exists key_devices_key_id_idx on public.key_devices(key_id);
