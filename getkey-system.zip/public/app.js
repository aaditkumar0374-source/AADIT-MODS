const $ = (id) => document.getElementById(id);
let challengeId = null;
$("start").addEventListener("click", async () => {
  $("message").textContent = "Starting checkpoint…";
  try {
    const r = await fetch("/api/checkpoint/start", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({}) });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error + (data.detail ? " " + data.detail : ""));
    challengeId = data.challengeId;
    $("checkpointBox").classList.remove("hidden");
    $("status").textContent = "Checkpoint started";
    window.open(data.shortlinkUrl, "_blank", "noopener");
    $("message").textContent = "Complete the shortlink in the new tab, then check status.";
  } catch (e) { $("message").textContent = e.message; }
});
$("check").addEventListener("click", async () => {
  if (!challengeId) return;
  try {
    const r = await fetch("/api/checkpoint/status/" + encodeURIComponent(challengeId));
    const data = await r.json();
    $("status").textContent = data.verified ? "Checkpoint verified" : "Not verified yet";
    $("message").textContent = data.verified ? "Checkpoint verified. Public key claiming must be configured by the site owner." : (data.error || "Finish the shortlink and try again.");
  } catch { $("message").textContent = "Could not check status. Try again."; }
});
