const $ = (id) => document.getElementById(id);
let token = "";
const headers = () => ({ "Content-Type":"application/json", "Authorization":"Bearer " + token });
function message(s) { $("message").textContent = s; }
function showDashboard() { $("login").classList.add("hidden"); $("dashboard").classList.remove("hidden"); }
$("expiryMode").addEventListener("change", () => {
  const custom = $("expiryMode").value === "custom";
  $("customWrap").classList.toggle("hidden", !custom);
  $("presetWrap").classList.toggle("hidden", custom);
});
$("loginBtn").addEventListener("click", async () => {
  try {
    const r = await fetch("/api/admin/login", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("username").value,password:$("password").value})});
    const d = await r.json(); if (!r.ok) throw new Error(d.error);
    token = d.token; showDashboard(); await refreshKeys(); message("Signed in.");
  } catch(e) { message(e.message); }
});
$("createBtn").addEventListener("click", async () => {
  try {
    const body = { expiryMode:$("expiryMode").value, maxDevices:Number($("maxDevices").value) };
    if (body.expiryMode === "preset") body.preset = $("preset").value;
    else {
      const v = $("expiresAt").value;
      if (!v) throw new Error("Choose a custom expiry date/time.");
      body.expiresAt = new Date(v).toISOString();
    }
    const r = await fetch("/api/admin/keys", {method:"POST",headers:headers(),body:JSON.stringify(body)});
    const d = await r.json(); if (!r.ok) throw new Error(d.error);
    $("keyValue").textContent = d.key; $("newKey").classList.remove("hidden");
    message("Key created. Copy and save it now; it will not be shown again.");
    await refreshKeys();
  } catch(e) { message(e.message); }
});
$("copyBtn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText($("keyValue").textContent); message("Key copied."); }
  catch { message("Copy failed. Select and copy the key manually."); }
});
async function refreshKeys() {
  const r = await fetch("/api/admin/keys", {headers:headers()}); const d = await r.json();
  if (!r.ok) throw new Error(d.error);
  $("keys").innerHTML = "";
  for (const k of d.keys) {
    const item = document.createElement("div"); item.className = "keyrow";
    const info = document.createElement("div");
    const strong = document.createElement("strong"); strong.textContent = k.key_prefix + "…";
    const meta = document.createElement("p"); meta.className = "small"; meta.textContent = `${k.status} · expires ${new Date(k.expires_at).toLocaleString()} · max devices ${k.max_devices}`;
    info.append(strong, meta);
    const btn = document.createElement("button"); btn.className = "danger"; btn.textContent = "Revoke";
    btn.addEventListener("click", async () => {
      if (!confirm("Revoke this key?")) return;
      const rr = await fetch(`/api/admin/keys/${encodeURIComponent(k.id)}/revoke`, {method:"POST",headers:headers()});
      const dd = await rr.json(); if (!rr.ok) return message(dd.error);
      await refreshKeys(); message("Key revoked.");
    });
    item.append(info, btn); $("keys").append(item);
  }
}
$("refreshBtn").addEventListener("click", () => refreshKeys().catch(e => message(e.message)));
$("logoutBtn").addEventListener("click", async () => {
  try { await fetch("/api/admin/logout",{method:"POST",headers:headers()}); } finally {
    token=""; $("dashboard").classList.add("hidden"); $("login").classList.remove("hidden"); message("Logged out.");
  }
});
